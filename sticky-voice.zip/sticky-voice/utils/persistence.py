"""Minimal JSON persistence for resume data. Write only on real change."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

log = logging.getLogger("sticky.persist")

DEFAULT_PATH = Path("data/sessions.json")


class SessionStore:
    def __init__(self, path: Path | str = DEFAULT_PATH) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data: Dict[str, Dict[str, Any]] = {}
        self._dirty = False
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            self._data = {}
            return
        try:
            with self.path.open("r", encoding="utf-8") as f:
                self._data = json.load(f)
        except Exception as e:
            log.warning("failed to load sessions.json: %s — starting empty", e)
            self._data = {}

    def get(self, token_key: str) -> Optional[Dict[str, Any]]:
        return self._data.get(token_key)

    def set(
        self,
        token_key: str,
        *,
        guild_id: int,
        channel_id: int,
        session_id: Optional[str] = None,
    ) -> None:
        new_entry = {
            "guild_id": guild_id,
            "channel_id": channel_id,
            "session_id": session_id,
        }
        old = self._data.get(token_key)
        if old == new_entry:
            return
        self._data[token_key] = new_entry
        self._dirty = True
        self._flush()

    def remove(self, token_key: str) -> None:
        if token_key in self._data:
            del self._data[token_key]
            self._dirty = True
            self._flush()

    def _flush(self) -> None:
        if not self._dirty:
            return
        try:
            tmp = self.path.with_suffix(".tmp")
            with tmp.open("w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False)
            tmp.replace(self.path)
            self._dirty = False
        except Exception as e:
            log.error("persist flush failed: %s", e)
