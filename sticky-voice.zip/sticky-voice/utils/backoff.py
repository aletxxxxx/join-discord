"""Exponential backoff with jitter — pure asyncio friendly."""

from __future__ import annotations

import random
from typing import Optional


class ExponentialBackoff:
    """
    2 → 4 → 8 → 16 → 32 → … capped at max_delay.
    Optional full-jitter to avoid thundering herd.
    """

    def __init__(
        self,
        base: float = 2.0,
        max_delay: float = 90.0,
        jitter: bool = True,
    ) -> None:
        self.base = base
        self.max_delay = max_delay
        self.jitter = jitter
        self._attempt = 0

    def reset(self) -> None:
        self._attempt = 0

    @property
    def attempt(self) -> int:
        return self._attempt

    def next(self) -> float:
        delay = min(self.base * (2 ** self._attempt), self.max_delay)
        self._attempt += 1
        if self.jitter:
            delay = random.uniform(delay * 0.5, delay)
        return delay

    def peek(self) -> float:
        delay = min(self.base * (2 ** self._attempt), self.max_delay)
        if self.jitter:
            return delay  # approximate
        return delay
