"""Parse tokens.txt — fault tolerant, sticky channel mapping."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("sticky.tokens")


@dataclass(frozen=True)
class TokenEntry:
    token: str
    channel_id: int
    line_no: int

    @property
    def key(self) -> str:
        """Stable short key for persistence (never full token)."""
        return self.token[:16] if len(self.token) >= 16 else self.token


def _clean_field(raw: str) -> str:
    return raw.strip().strip("()[]{}\"'")


def parse_tokens_file(path: str | Path = "tokens.txt") -> List[TokenEntry]:
    """
    Parse tokens.txt.
    Format per line: token:channel_id
    - Skip blank / # comments
    - Strip whitespace and surrounding ()
    - Bad line → log + skip (never crash)
    - Duplicate token → keep first, warn later lines
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"tokens file not found: {path}")

    seen: Dict[str, int] = {}
    result: List[TokenEntry] = []

    with path.open("r", encoding="utf-8", errors="replace") as f:
        for line_no, line in enumerate(f, start=1):
            raw = line.strip()
            if not raw or raw.startswith("#"):
                continue

            if ":" not in raw:
                log.error("line %d: missing ':' separator — skipped", line_no)
                continue

            # Split on last colon in case token somehow contains one (rare)
            # Standard Discord tokens do not contain ':'.
            parts = raw.rsplit(":", 1)
            if len(parts) != 2:
                log.error("line %d: invalid format — skipped", line_no)
                continue

            token = _clean_field(parts[0])
            channel_raw = _clean_field(parts[1])

            if not token or len(token) < 20:
                log.error("line %d: token too short / empty — skipped", line_no)
                continue

            if not channel_raw.isdigit():
                log.error(
                    "line %d: channel_id must be numeric, got %r — skipped",
                    line_no,
                    channel_raw,
                )
                continue

            channel_id = int(channel_raw)

            if token in seen:
                log.warning(
                    "line %d: duplicate token (first seen line %d) — ignored",
                    line_no,
                    seen[token],
                )
                continue

            seen[token] = line_no
            result.append(TokenEntry(token=token, channel_id=channel_id, line_no=line_no))

    log.info("loaded %d unique token(s) from %s", len(result), path)
    return result
