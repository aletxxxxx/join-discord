"""Configuration loader and typed settings."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import yaml


@dataclass(frozen=True)
class Settings:
    guild_id: int
    join_delay_min: float
    join_delay_max: float
    max_concurrent_joins: int
    enable_empty_opus: bool
    empty_opus_interval: float
    log_level: str
    quarantine_minutes: int
    max_fail_before_quarantine: int
    status_interval: float
    backoff_base: float
    backoff_max: float
    proxy: Optional[str] = None


def load_config(path: str | Path = "config.yaml") -> Settings:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"config not found: {path}")

    with path.open("r", encoding="utf-8") as f:
        raw: dict[str, Any] = yaml.safe_load(f) or {}

    guild_raw = str(raw.get("guild_id", "")).strip().strip('"').strip("'")
    if not guild_raw.isdigit():
        raise ValueError("guild_id must be a numeric string in config.yaml")

    return Settings(
        guild_id=int(guild_raw),
        join_delay_min=float(raw.get("join_delay_min", 5)),
        join_delay_max=float(raw.get("join_delay_max", 12)),
        max_concurrent_joins=int(raw.get("max_concurrent_joins", 6)),
        enable_empty_opus=bool(raw.get("enable_empty_opus", True)),
        empty_opus_interval=float(raw.get("empty_opus_interval", 8)),
        log_level=str(raw.get("log_level", "INFO")).upper(),
        quarantine_minutes=int(raw.get("quarantine_minutes", 45)),
        max_fail_before_quarantine=int(raw.get("max_fail_before_quarantine", 6)),
        status_interval=float(raw.get("status_interval", 60)),
        backoff_base=float(raw.get("backoff_base", 2)),
        backoff_max=float(raw.get("backoff_max", 90)),
        proxy=(str(raw["proxy"]).strip() if raw.get("proxy") else None),
    )
