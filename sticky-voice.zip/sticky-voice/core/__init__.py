"""Core package for sticky voice keep-alive."""
