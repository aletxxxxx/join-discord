"""Non-blocking, structured logger with token prefix support."""

from __future__ import annotations

import logging
import sys
from typing import Optional


_TOKEN_PREFIX_LEN = 8


def token_prefix(token: str) -> str:
    """Short safe prefix for logs (never full token)."""
    clean = token.strip()
    if len(clean) <= _TOKEN_PREFIX_LEN:
        return clean[:4] + "…"
    return clean[:_TOKEN_PREFIX_LEN] + "…"


def setup_logging(level: str = "INFO") -> logging.Logger:
    """Configure root logger once. Safe to call multiple times."""
    root = logging.getLogger()
    if root.handlers:
        root.setLevel(getattr(logging, level, logging.INFO))
        return logging.getLogger("sticky")

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    root.addHandler(handler)
    root.setLevel(getattr(logging, level, logging.INFO))

    # Quiet noisy libraries
    logging.getLogger("discord").setLevel(logging.WARNING)
    logging.getLogger("discord.gateway").setLevel(logging.WARNING)
    logging.getLogger("discord.client").setLevel(logging.WARNING)
    logging.getLogger("discord.voice_client").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)

    return logging.getLogger("sticky")


def get_token_logger(token: str) -> logging.LoggerAdapter:
    """Logger that always prefixes messages with short token id."""
    base = logging.getLogger("sticky")
    prefix = token_prefix(token)
    return logging.LoggerAdapter(base, {"token": prefix})


class TokenFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, "token"):
            record.token = "-"  # type: ignore[attr-defined]
        return True
