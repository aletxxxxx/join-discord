"""Orchestrator — spawn isolated workers, staggered join, status loop, clean shutdown."""

from __future__ import annotations

import asyncio
import logging
import random
import signal
from typing import Dict, List, Optional

from core.config import Settings
from core.token_manager import TokenEntry, parse_tokens_file
from utils.persistence import SessionStore
from worker.voice_worker import VoiceWorker, WorkerState

log = logging.getLogger("sticky.orch")


class Orchestrator:
    def __init__(self, settings: Settings, tokens_path: str = "tokens.txt") -> None:
        self.settings = settings
        self.tokens_path = tokens_path
        self.store = SessionStore()
        self.workers: Dict[str, VoiceWorker] = {}
        self._tasks: List[asyncio.Task] = []
        self._stop_event = asyncio.Event()
        self._join_sem = asyncio.Semaphore(settings.max_concurrent_joins)
        self._status_task: Optional[asyncio.Task] = None

    async def run(self) -> None:
        entries = parse_tokens_file(self.tokens_path)
        if not entries:
            log.error("no valid tokens found — nothing to do")
            return

        log.info(
            "orchestrator start — %d token(s), guild=%s, max_joins=%d",
            len(entries),
            self.settings.guild_id,
            self.settings.max_concurrent_joins,
        )

        # Staggered launch
        for i, entry in enumerate(entries):
            if self._stop_event.is_set():
                break
            worker = VoiceWorker(
                token=entry.token,
                channel_id=entry.channel_id,
                settings=self.settings,
                store=self.store,
                join_semaphore=self._join_sem,
            )
            self.workers[entry.token] = worker
            task = worker.start()
            self._tasks.append(task)

            # Random delay before next token starts joining
            if i < len(entries) - 1:
                delay = random.uniform(
                    self.settings.join_delay_min,
                    self.settings.join_delay_max,
                )
                log.info("next join in %.1fs", delay)
                try:
                    await asyncio.wait_for(self._stop_event.wait(), timeout=delay)
                    break
                except asyncio.TimeoutError:
                    pass

        self._status_task = asyncio.create_task(self._status_loop())

        # Wait until stop
        await self._stop_event.wait()
        await self.shutdown()

    async def shutdown(self) -> None:
        log.info("shutting down cleanly…")
        self._stop_event.set()

        if self._status_task and not self._status_task.done():
            self._status_task.cancel()
            try:
                await self._status_task
            except asyncio.CancelledError:
                pass

        # Stop all workers concurrently
        stop_coros = [w.stop() for w in self.workers.values()]
        if stop_coros:
            await asyncio.gather(*stop_coros, return_exceptions=True)

        # Cancel leftover tasks
        for t in self._tasks:
            if not t.done():
                t.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)

        log.info("all workers stopped")

    async def _status_loop(self) -> None:
        interval = self.settings.status_interval
        while not self._stop_event.is_set():
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=interval)
                break
            except asyncio.TimeoutError:
                self._print_status()

    def _print_status(self) -> None:
        counts = {
            "joined": 0,
            "reconnecting": 0,
            "quarantined": 0,
            "dead": 0,
            "other": 0,
        }
        lines: List[str] = []
        for w in self.workers.values():
            lines.append("  " + w.status_line())
            s = w.state
            if s == WorkerState.JOINED:
                counts["joined"] += 1
            elif s in (WorkerState.RECONNECTING, WorkerState.JOINING, WorkerState.STARTING):
                counts["reconnecting"] += 1
            elif s == WorkerState.QUARANTINED:
                counts["quarantined"] += 1
            elif s == WorkerState.DEAD:
                counts["dead"] += 1
            else:
                counts["other"] += 1

        summary = (
            f"STATUS | live={counts['joined']} "
            f"reconnect={counts['reconnecting']} "
            f"quarantine={counts['quarantined']} "
            f"dead={counts['dead']} "
            f"other={counts['other']} "
            f"total={len(self.workers)}"
        )
        log.info(summary)
        for line in lines:
            log.info(line)

    def request_stop(self) -> None:
        self._stop_event.set()
