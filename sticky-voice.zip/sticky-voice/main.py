#!/usr/bin/env python3
"""
Sticky Voice Keep-Alive — multi-token Discord selfbot
Mỗi token gắn cứng 1 voice channel, giữ kết nối 24/7, isolated.
"""

from __future__ import annotations

import asyncio
import logging
import signal
import sys
from pathlib import Path

from core.config import load_config
from core.logger import setup_logging
from core.orchestrator import Orchestrator

log = logging.getLogger("sticky")


async def amain() -> int:
    # Load config first so we can set log level
    try:
        settings = load_config("config.yaml")
    except Exception as e:
        print(f"FATAL: cannot load config.yaml — {e}", file=sys.stderr)
        return 1

    setup_logging(settings.log_level)
    log.info("sticky-voice starting (Python %s)", sys.version.split()[0])

    if not Path("tokens.txt").exists():
        log.error("tokens.txt not found — create it and try again")
        return 1

    orch = Orchestrator(settings)

    loop = asyncio.get_running_loop()

    def _signal_handler() -> None:
        log.info("signal received — graceful shutdown")
        orch.request_stop()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _signal_handler)
        except NotImplementedError:
            # Windows
            signal.signal(sig, lambda *_: _signal_handler())

    try:
        await orch.run()
    except Exception as e:
        log.exception("orchestrator crashed: %s", e)
        return 1
    finally:
        await orch.shutdown()

    log.info("exit clean")
    return 0


def main() -> None:
    try:
        raise SystemExit(asyncio.run(amain()))
    except KeyboardInterrupt:
        print("\ninterrupted", file=sys.stderr)
        raise SystemExit(0)


if __name__ == "__main__":
    main()
