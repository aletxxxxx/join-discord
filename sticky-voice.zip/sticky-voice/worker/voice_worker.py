"""Per-token sticky voice worker — fully isolated asyncio Task."""

from __future__ import annotations

import asyncio
import enum
import logging
import time
from typing import Optional

import discord
from discord import VoiceChannel, VoiceClient
from discord.errors import (
    ConnectionClosed,
    Forbidden,
    HTTPException,
    LoginFailure,
)

from core.config import Settings
from core.logger import token_prefix
from utils.backoff import ExponentialBackoff
from utils.persistence import SessionStore
from worker.connection import (
    connect_voice,
    ensure_silent_play,
    stop_and_disconnect,
)

log = logging.getLogger("sticky.worker")


class WorkerState(enum.Enum):
    STARTING = "starting"
    JOINING = "joining"
    JOINED = "joined"
    DISCONNECTED = "disconnected"
    RECONNECTING = "reconnecting"
    QUARANTINED = "quarantined"
    DEAD = "dead"
    ERROR = "error"
    STOPPED = "stopped"


class VoiceWorker:
    """
    One token → one sticky channel.
    Completely isolated: exceptions never propagate to other workers.
    """

    def __init__(
        self,
        token: str,
        channel_id: int,
        settings: Settings,
        store: SessionStore,
        join_semaphore: asyncio.Semaphore,
    ) -> None:
        self.token = token
        self.channel_id = channel_id
        self.settings = settings
        self.store = store
        self.join_sem = join_semaphore

        self.prefix = token_prefix(token)
        self.state = WorkerState.STARTING
        self.fail_count = 0
        self.quarantine_until: float = 0.0
        self.client: Optional[discord.Client] = None
        self.vc: Optional[VoiceClient] = None
        self._task: Optional[asyncio.Task] = None
        self._stop_event = asyncio.Event()
        self._backoff = ExponentialBackoff(
            base=settings.backoff_base,
            max_delay=settings.backoff_max,
        )
        self._joined_at: float = 0.0
        self._last_error: str = ""

    # ── public API ──────────────────────────────────────────────

    def start(self) -> asyncio.Task:
        self._task = asyncio.create_task(self._run(), name=f"voice-{self.prefix}")
        return self._task

    async def stop(self) -> None:
        self._stop_event.set()
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self._cleanup()

    @property
    def is_alive(self) -> bool:
        return self.state in {
            WorkerState.JOINED,
            WorkerState.JOINING,
            WorkerState.RECONNECTING,
            WorkerState.STARTING,
        }

    def status_line(self) -> str:
        extra = ""
        if self.state == WorkerState.QUARANTINED:
            remaining = max(0, int(self.quarantine_until - time.time()))
            extra = f" ({remaining}s left)"
        elif self.state == WorkerState.DEAD:
            extra = f" ({self._last_error})"
        elif self.state == WorkerState.JOINED and self._joined_at:
            up = int(time.time() - self._joined_at)
            extra = f" (up {up}s)"
        return f"{self.prefix} → ch:{self.channel_id} [{self.state.value}]{extra}"

    # ── main loop ───────────────────────────────────────────────

    async def _run(self) -> None:
        self._log("starting")
        while not self._stop_event.is_set():
            try:
                if self.state == WorkerState.DEAD:
                    await asyncio.sleep(3600)  # park forever
                    continue

                if self.state == WorkerState.QUARANTINED:
                    wait = self.quarantine_until - time.time()
                    if wait > 0:
                        self._log(f"quarantined, sleep {int(wait)}s")
                        try:
                            await asyncio.wait_for(
                                self._stop_event.wait(), timeout=wait
                            )
                            break
                        except asyncio.TimeoutError:
                            pass
                    self.fail_count = 0
                    self._backoff.reset()
                    self.state = WorkerState.STARTING
                    continue

                await self._session_loop()

            except asyncio.CancelledError:
                break
            except Exception as e:
                self._last_error = str(e)
                self._log(f"unhandled: {e}", level=logging.ERROR)
                self.state = WorkerState.ERROR
                await self._handle_failure(is_auth=False)

        await self._cleanup()
        self.state = WorkerState.STOPPED
        self._log("stopped")

    async def _session_loop(self) -> None:
        """One full login → join → keep-alive cycle."""
        self.state = WorkerState.STARTING
        client = discord.Client(
            chunk_guilds_at_startup=False,
            guild_subscriptions=False,
            max_messages=0,
        )
        self.client = client

        @client.event
        async def on_ready() -> None:
            self._log(f"gateway ready as {client.user}")

        try:
            # Login
            await client.login(self.token)
        except LoginFailure as e:
            self._last_error = "LoginFailure / invalid token"
            self._log("DEAD — authentication failed", level=logging.ERROR)
            self.state = WorkerState.DEAD
            await client.close()
            self.client = None
            return
        except (HTTPException, Forbidden) as e:
            status = getattr(e, "status", None)
            if status in (401, 403):
                self._last_error = f"HTTP {status}"
                self._log(f"DEAD — HTTP {status}", level=logging.ERROR)
                self.state = WorkerState.DEAD
                await client.close()
                self.client = None
                return
            raise

        # Connect gateway in background
        connect_task = asyncio.create_task(client.connect(reconnect=True))

        try:
            # Wait until ready (or timeout)
            for _ in range(40):
                if self._stop_event.is_set():
                    return
                if client.is_ready():
                    break
                await asyncio.sleep(0.5)
            else:
                raise TimeoutError("gateway ready timeout")

            # Resolve channel
            channel = client.get_channel(self.channel_id)
            if channel is None:
                # Try fetch
                try:
                    channel = await client.fetch_channel(self.channel_id)
                except Exception as e:
                    raise RuntimeError(f"cannot resolve channel {self.channel_id}: {e}") from e

            if not isinstance(channel, VoiceChannel):
                raise RuntimeError(f"channel {self.channel_id} is not a VoiceChannel")

            if channel.guild.id != self.settings.guild_id:
                self._log(
                    f"warning: channel guild {channel.guild.id} != config guild_id "
                    f"{self.settings.guild_id}",
                    level=logging.WARNING,
                )

            # Join with semaphore + delay already handled by orchestrator
            async with self.join_sem:
                if self._stop_event.is_set():
                    return
                self.state = WorkerState.JOINING
                self._log(f"joining channel {self.channel_id}")
                self.vc = await connect_voice(
                    client,
                    channel,
                    self_mute=True,
                    self_deaf=True,
                    timeout=30.0,
                )

            self.state = WorkerState.JOINED
            self._joined_at = time.time()
            self.fail_count = 0
            self._backoff.reset()
            self._log("joined sticky")

            # Persist
            self.store.set(
                token_key=self.token[:16],
                guild_id=channel.guild.id,
                channel_id=self.channel_id,
                session_id=getattr(self.vc, "session_id", None),
            )

            # Keep-alive loop
            await self._keep_alive(client)

        except asyncio.CancelledError:
            raise
        except Exception as e:
            self._last_error = str(e)
            is_auth = self._is_auth_error(e)
            self._log(f"session error: {e}", level=logging.ERROR)
            await self._handle_failure(is_auth=is_auth)
        finally:
            await stop_and_disconnect(self.vc, force=True)
            self.vc = None
            try:
                if not client.is_closed():
                    await client.close()
            except Exception:
                pass
            self.client = None
            if not connect_task.done():
                connect_task.cancel()
                try:
                    await connect_task
                except (asyncio.CancelledError, Exception):
                    pass

    async def _keep_alive(self, client: discord.Client) -> None:
        """Stay in voice, send silent Opus, detect disconnects."""
        interval = self.settings.empty_opus_interval
        enable_opus = self.settings.enable_empty_opus

        while not self._stop_event.is_set():
            if client.is_closed() or not client.is_ready():
                raise ConnectionClosed(None, code=1000)  # type: ignore[arg-type]

            vc = self.vc
            if vc is None or not vc.is_connected():
                self.state = WorkerState.DISCONNECTED
                raise RuntimeError("voice disconnected")

            # Sticky check — force back if somehow moved
            if vc.channel and vc.channel.id != self.channel_id:
                self._log(
                    f"moved away from sticky channel → reconnecting",
                    level=logging.WARNING,
                )
                raise RuntimeError("left sticky channel")

            if enable_opus:
                await ensure_silent_play(vc)

            # Sleep in small slices so stop is responsive
            for _ in range(int(interval * 2)):
                if self._stop_event.is_set():
                    return
                await asyncio.sleep(0.5)

    async def _handle_failure(self, *, is_auth: bool) -> None:
        await stop_and_disconnect(self.vc, force=True)
        self.vc = None

        if is_auth:
            self.state = WorkerState.DEAD
            self._log("marked DEAD — no more retries", level=logging.ERROR)
            return

        self.fail_count += 1
        if self.fail_count >= self.settings.max_fail_before_quarantine:
            self.state = WorkerState.QUARANTINED
            self.quarantine_until = time.time() + self.settings.quarantine_minutes * 60
            self._log(
                f"quarantine {self.settings.quarantine_minutes}m after "
                f"{self.fail_count} fails",
                level=logging.WARNING,
            )
            return

        self.state = WorkerState.RECONNECTING
        delay = self._backoff.next()
        self._log(f"reconnect in {delay:.1f}s (fail #{self.fail_count})")
        try:
            await asyncio.wait_for(self._stop_event.wait(), timeout=delay)
        except asyncio.TimeoutError:
            pass

    async def _cleanup(self) -> None:
        await stop_and_disconnect(self.vc, force=True)
        self.vc = None
        if self.client and not self.client.is_closed():
            try:
                await self.client.close()
            except Exception:
                pass
        self.client = None

    def _is_auth_error(self, exc: BaseException) -> bool:
        if isinstance(exc, LoginFailure):
            return True
        if isinstance(exc, (HTTPException, Forbidden)):
            status = getattr(exc, "status", None)
            if status in (401, 403):
                return True
        msg = str(exc).lower()
        return any(
            k in msg
            for k in (
                "401",
                "403",
                "unauthorized",
                "invalid token",
                "authentication",
                "improper token",
            )
        )

    def _log(self, msg: str, level: int = logging.INFO) -> None:
        log.log(level, "[%s] %s", self.prefix, msg)
