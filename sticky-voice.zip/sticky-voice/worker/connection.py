"""Low-level helpers around discord.py-self voice connection."""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

import discord
from discord import VoiceChannel, VoiceClient

log = logging.getLogger("sticky.conn")

# Pre-built silent Opus frame (20ms silence, TOC + 0-byte frame)
# This is the standard empty Opus packet Discord accepts.
SILENT_OPUS_FRAME = b"\xf8\xff\xfe"


class SilentOpusSource(discord.AudioSource):
    """Extremely cheap silent source — returns the same buffer every read."""

    def __init__(self) -> None:
        self._frame = SILENT_OPUS_FRAME

    def read(self) -> bytes:
        return self._frame

    def is_opus(self) -> bool:
        return True

    def cleanup(self) -> None:
        pass


async def connect_voice(
    client: discord.Client,
    channel: VoiceChannel,
    *,
    self_mute: bool = True,
    self_deaf: bool = True,
    timeout: float = 30.0,
) -> VoiceClient:
    """
    Join a voice channel with sticky mute/deaf.
    Raises on failure so caller can decide retry / dead / quarantine.
    """
    if client.user is None:
        raise RuntimeError("client not ready")

    # Already connected somewhere?
    existing = discord.utils.get(client.voice_clients, guild=channel.guild)
    if existing and existing.is_connected():
        if existing.channel and existing.channel.id == channel.id:
            return existing  # type: ignore[return-value]
        await existing.disconnect(force=True)

    vc: VoiceClient = await channel.connect(
        timeout=timeout,
        reconnect=False,
        self_mute=self_mute,
        self_deaf=self_deaf,
    )
    return vc


async def ensure_silent_play(vc: VoiceClient) -> None:
    """Start (or restart) silent Opus playback if not already playing."""
    if not vc.is_connected():
        return
    if vc.is_playing():
        return
    try:
        source = SilentOpusSource()
        vc.play(source, after=None)
    except Exception as e:
        log.debug("silent play start failed: %s", e)


async def stop_and_disconnect(vc: Optional[VoiceClient], *, force: bool = False) -> None:
    if vc is None:
        return
    try:
        if vc.is_playing():
            vc.stop()
    except Exception:
        pass
    try:
        if vc.is_connected():
            await vc.disconnect(force=force)
    except Exception:
        pass
